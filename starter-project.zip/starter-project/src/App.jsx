import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";

import Header from "./components/Header";
import Footer from "./components/Footer";

import Home from "./pages/Home";
import About from "./pages/About";
import Products from "./pages/Products";   
import Contact from "./pages/Contact";


function App() {
  const [reducedMotion, setReducedMotion] = useState(false);

  useEffect(() => {
    const mediaQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
    const handleChange = (e) => {
      if (e.matches) setReducedMotion(true);
      else setReducedMotion(false);
    };
    handleChange(mediaQuery);
    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, []);

  const toggleReducedMotion = () => {
    setReducedMotion((prev) => !prev);
  };

  return (
    <BrowserRouter>
      <div className={`app ${reducedMotion ? "reduced-motion" : ""}`}>
        <Header />
        <button
          onClick={toggleReducedMotion}
          style={{
            position: "fixed",
            bottom: "20px",
            right: "20px",
            zIndex: 1000,
            background: "rgba(226,184,122,0.2)",
            border: "1px solid #e2b87a",
            borderRadius: "40px",
            padding: "8px 16px",
            color: "#e2b87a",
            cursor: "pointer",
            fontSize: "0.8rem",
            backdropFilter: "blur(4px)",
            fontFamily: "inherit",
          }}
        >
          {reducedMotion ? "Enable Animations" : "Reduce Motion"}
        </button>
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/products" element={<Products />} /> 
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;